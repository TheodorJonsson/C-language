/**
 * @file frequence.c
 * @author your name (you@domain.com)
 * @brief
 * @version 0.1
 * @date 2022-02-09
 *
 * @copyright Copyright (c) 2022
 *
 */

#include "huffman_trie.h"


struct trie_node new_node(char data, int freq)
{
  struct trie_node *new = malloc(sizeof(struct trie_node));

  new->freq = freq;
  new->data = data;
  new->right_child = NULL;
  new->left_child = NULL;

  return new;
}


trie create_huffman(pqueue *pq)
{
  struct trie_node *left, *right, *parent;
  queue_elem *q_elem;

  while(!pqueue_is_empty(pq))
  {
    q_elem = (queue_elem *)pqueue_inspect_first(pq);
    pqueue_delete_first(pq);
    left = new_node(q_elem->character, q_elem->freq);
    q_elem = (queue_elem *)pqueue_inspect_first(pq);
    pqueue_delete_first(pq)
    right = new_node(q_elem->character, q_elem->freq);

    parent = new_node(NULL, right->freq + left_freq);
    parent->right_child = right;
    parent->left_child = left;

    pqueue_insert(pq, parent);
  }
}
